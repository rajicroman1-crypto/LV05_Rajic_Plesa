#include<iostream>
using namespace std;
int main() {
	int zagreb_domaci;
	int zagreb_gosti;
	int split_domaci;
	int split_gosti;
	cout << "Unesi redom: (zagreb_domaci, zagreb_gosti, split_domaci, split_gosti) :";
	cin >> zagreb_domaci >> zagreb_gosti >> split_domaci >> split_gosti;
	int ukupno_zagreb = zagreb_domaci + zagreb_gosti;
	int ukupno_split = split_domaci + split_gosti;
	cout << endl;
	if (ukupno_zagreb > ukupno_split)
		cout << "Zagreb pobjeduje - razlika u golovima je: " << (ukupno_zagreb - ukupno_split) << endl;

	else if (ukupno_zagreb < ukupno_split)
		cout << "Split pobjeduje - razlika u golovima je: " << (ukupno_split - ukupno_zagreb) << endl;


	else
		if (zagreb_gosti > split_gosti)
			cout << "Split pobjeduje - razlika u golovima je: " << (ukupno_zagreb - ukupno_split) << endl;
	else if (zagreb_gosti<split_gosti)
		cout << "Zagreb pobjeduje - razlika u golovima je: " << (ukupno_split - ukupno_zagreb) << endl;

	else(ukupno_zagreb == ukupno_split);

		cout << "Jedanaesterci";
	

	
	return 0;
}